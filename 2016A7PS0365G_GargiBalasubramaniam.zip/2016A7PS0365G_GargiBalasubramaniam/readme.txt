This folder should be explored in the following manner:
1. First read the PDF manual.
2. Then explore the Jupyter Notebook (THE HTML HAS BEEN ATTACHED FOR A QUICK GLANCE AT THE NOTEBOOK)
3. The CNF files can be explored after this. (optional)